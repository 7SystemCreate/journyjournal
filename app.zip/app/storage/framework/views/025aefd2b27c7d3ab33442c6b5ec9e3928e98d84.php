

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- 左側: 予約情報入力フォーム -->
        <div class="col-md-6">
            <div class="card p-4 h-100">
                <h4 class="mb-3">予約情報を入力</h4>
                    <div class= 'panel-body'>
                        <?php if($errors->any()): ?>
                        <div class='alert alert-danger'>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                <form action="<?php echo e(route('booking.conf', ['post' => $post->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                    <div class="mb-3">
                        <label class="form-label">氏名</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">電話番号</label>
                        <input type="tel" name="tel" value="<?php echo e(old('tel')); ?>" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">チェックイン日</label>
                        <input type="date" name="checkin_date" class="form-control" value="<?php echo e($post->date); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">チェックアウト日</label>
                        <input type="date" name="checkout_date" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($post->date)->addDay()->format('Y-m-d')); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">予約人数</label>
                        <input type="number" name="booking_people" value="<?php echo e(old('booking_people')); ?>" class="form-control" min="1" max="<?php echo e($post->max_people); ?>" required>
                    </div>

                    <div class="d-flex justify-content-center mt-3">
                        <button type="submit" class="btn btn-success btn-lg">確認</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- 右側: 予約のタイトル・料金詳細 -->
        <div class="col-md-6">
            <div class="card p-4 h-100">
                <h4 class="mb-3"><?php echo e($post->title); ?></h4>
                <p class="text-muted"><?php echo e($post->comment); ?></p> <!-- コメント -->

                <!-- 金額を目立たせる、少し大きくし下に表示 -->
                <div class="bg-light p-3 rounded text-center mt-4">
                    <p class="fw-bold fs-3 mb-0">金額: <?php echo e(number_format($post->amount)); ?> 円</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/booking.blade.php ENDPATH**/ ?>
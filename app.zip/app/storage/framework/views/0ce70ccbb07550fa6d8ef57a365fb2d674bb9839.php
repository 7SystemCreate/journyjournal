

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- 左側: 投稿の詳細情報 -->
        <div class="col-md-6">
            <div class="card p-4 h-100">
                <h4 class="mb-3">予約内容確認</h4>
                <table class="table">
                    <tr>
                        <th>予約者氏名</th>
                        <td><?php echo e($booking->name); ?></td>
                    </tr>
                    <tr>
                        <th>電話番号</th>
                        <td><?php echo e($booking->tel); ?></td>
                    </tr>
                    <tr>
                        <th>チェックイン時間</th>
                        <td><?php echo e($booking->checkin_date); ?></td>
                    </tr>
                    <tr>
                        <th>チェックアウト時間</th>
                        <td><?php echo e($booking->checkout_date); ?></td>
                    </tr>
                    <tr>
                        <th>人数</th>
                        <td><?php echo e($booking->booking_people); ?>人</td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- 右側: 料金詳細と予約ボタン -->
        <div class="col-md-6">
            <div class="card p-4 h-100 d-flex flex-column justify-content-between">
                <h4 class="mb-3"><?php echo e($post->title); ?></h4>
                <p class="text-muted"><?php echo e($post->comment); ?></p>
                <div class="bg-light p-3 rounded text-center">
                    <p class="fw-bold fs-4 mb-0">金額: <?php echo e(number_format($post->amount)); ?> 円</p>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/innbooking_detail.blade.php ENDPATH**/ ?>
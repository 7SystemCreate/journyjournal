

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-center font-weight-bold my-4">予約一覧</h2>

    <?php if($bookings->isEmpty()): ?>
        <p>現在、予約はありません。</p>
    <?php else: ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>予約者氏名</th>
                    <th>チェックイン日</th>
                    <th>チェックアウト日</th>
                    <th>予約人数</th>
                    <th>料金</th>
                    <th>予約日</th>
                    <th>ステータス</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($booking->name); ?></td>
                    <td><?php echo e($booking->checkin_date); ?></td>
                    <td><?php echo e($booking->checkout_date); ?></td>
                    <td><?php echo e($booking->booking_people); ?>人</td>
                    <td><?php echo e($booking->post->amount); ?>円</td>
                    <td><?php echo e($booking->created_at->format('Y-m-d')); ?></td>
                    <td>
                        <a href="<?php echo e(route('inn.booking.detail', ['booking' => $booking->id])); ?>" class="btn btn-primary btn-sm">
                            詳細を見る
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/innbooking_list.blade.php ENDPATH**/ ?>
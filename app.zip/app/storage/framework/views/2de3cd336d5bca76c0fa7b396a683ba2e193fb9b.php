

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-4 text-center">
                <h2 class="mb-3">予約が完了しました</h2>
                <p class="text-muted">ご予約いただきありがとうございます。詳細はマイページから確認できます。</p>

                <div class="mt-4">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg">メイン画面へ</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/booking_comp.blade.php ENDPATH**/ ?>
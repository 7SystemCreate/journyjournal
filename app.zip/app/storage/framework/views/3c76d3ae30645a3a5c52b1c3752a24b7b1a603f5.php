

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card p-4">
        <!-- タイトル -->
        <h2 class="mb-3"><?php echo e($post->title); ?></h2>

        <div class="row">
            <!-- 左側: 画像 -->
            <div class="col-md-6">
                <img src="<?php echo e(asset('storage/' . ($post->image ?? 'images/postimages/defaultimage.png'))); ?>" class="img-fluid rounded" alt="投稿画像">
            </div>

            <!-- 右側: 投稿情報 -->
            <div class="col-md-6">
                <p><strong>予約可能日:</strong> <?php echo e($post->date ?? '未定'); ?></p>
                <p><strong>予約可能人数:</strong> <?php echo e($post->max_people ?? '未定'); ?></p>
                <p><strong>金額:</strong> <?php echo e(number_format($post->amount)); ?> 円</p>

                <!-- 投稿者情報 -->
                <div class="d-flex align-items-center">
                    <img src="<?php echo e(asset('storage/' . ($post->user->icon ?? 'images/icon/defaulticon.png'))); ?>" 
                         class="rounded-circle me-2"
                         style="width: 50px; height: 50px; object-fit: cover;"
                         alt="ユーザーアイコン">
                    <p class="mb-0"><?php echo e($post->user->name ?? '投稿者不明'); ?></p>
                </div>

                <!-- ボタン -->
                <div class="mt-3 d-flex justify-content-between">
                    <!-- いいねボタン -->
                    <?php if(auth()->guard()->check()): ?>
                        <?php if($post->isLikedByUser(Auth::id())): ?>
                            <button id="like-btn-<?php echo e($post->id); ?>" type="button" class="btn btn-outline-danger"
                                    onclick="unlikePost(<?php echo e($post->id); ?>)">
                                いいねを取り消す <span id="like-count-<?php echo e($post->id); ?>"><?php echo e($post->likeCount()); ?></span>
                            </button>
                        <?php else: ?>
                            <button id="like-btn-<?php echo e($post->id); ?>" type="button" class="btn btn-outline-primary"
                                    onclick="likePost(<?php echo e($post->id); ?>)">
                                いいね！ <span id="like-count-<?php echo e($post->id); ?>"><?php echo e($post->likeCount()); ?></span>
                            </button>
                        <?php endif; ?>
                    <?php else: ?>
                        <button type="button" class="btn btn-outline-primary" disabled>
                            ログインしていいね！
                            <span id="like-count-<?php echo e($post->id); ?>"><?php echo e($post->likeCount()); ?></span>
                        </button>
                    <?php endif; ?>

                    <!-- 通報ボタン -->
                    <a href="<?php echo e(route('post.report', ['post' => $post['id']])); ?>" class="btn btn-warning">通報</a>

                    <!-- 予約ボタン -->
                    <a href="<?php echo e(route('booking', ['post' => $post['id']])); ?>" class="btn btn-success">予約する</a>
                </div>
            </div>
        </div>
    </div>

    <!-- コメント (投稿の説明文) を予約ボタンの下に配置 -->
    <div class="card mt-4 p-4">
        <h4>詳細</h4>
        <p><?php echo e($post->comment); ?></p>
    </div>
</div>

<!-- Ajax用のスクリプト -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function likePost(postId) {
        $.ajax({
            url: '<?php echo e(route('post.like', ['post' => ':post_id'])); ?>'.replace(':post_id', postId),
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('#like-count-' + postId).text(response.like_count);
                    $('#like-btn-' + postId)
                        .removeClass('btn-outline-primary')
                        .addClass('btn-outline-danger')
                        .html(`いいねを取り消す <span id="like-count-${postId}">${response.like_count}</span>`)
                        .attr('onclick', 'unlikePost(' + postId + ')');
                } else {
                    alert('いいねの追加に失敗しました。');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('エラーが発生しました: ' + errorThrown);
                console.error(jqXHR.responseText);
            }
        });
    }

    function unlikePost(postId) {
        $.ajax({
            url: '<?php echo e(route('post.unlike', ['post' => ':post_id'])); ?>'.replace(':post_id', postId),
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('#like-count-' + postId).text(response.like_count);
                    $('#like-btn-' + postId)
                        .removeClass('btn-outline-danger')
                        .addClass('btn-outline-primary')
                        .html(`いいね！ <span id="like-count-${postId}">${response.like_count}</span>`)
                        .attr('onclick', 'likePost(' + postId + ')');
                } else {
                    alert('いいねの削除に失敗しました。');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('エラーが発生しました: ' + errorThrown);
                console.error(jqXHR.responseText);
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/post_detail.blade.php ENDPATH**/ ?>
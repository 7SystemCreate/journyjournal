

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card p-5 text-center">
                <h2 class="mb-4 fw-bold">アカウント情報確認</h2>

                <form action="<?php echo e(route('account.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4 text-start mx-auto" style="max-width: 500px;">
                        <!-- ユーザ名 -->
                        <div class="row mb-3 align-items-center">
                            <label class="col-md-4 text-end fw-bold fs-5">ユーザ名:</label>
                            <div class="col-md-8 fs-5">
                                <?php echo e($userData['name']); ?>

                                <input type="hidden" name="name" value="<?php echo e($userData['name']); ?>">
                            </div>
                        </div>

                        <!-- メールアドレス -->
                        <div class="row mb-3 align-items-center">
                            <label class="col-md-4 text-end fw-bold fs-5">メールアドレス:</label>
                            <div class="col-md-8 fs-5">
                                <?php echo e($userData['email']); ?>

                                <input type="hidden" name="email" value="<?php echo e($userData['email']); ?>">
                            </div>
                        </div>

                        <!-- アイコンプレビュー -->
                        <div class="row mb-3 align-items-center">
                            <label class="col-md-4 text-end fw-bold fs-5">アイコン:</label>
                            <div class="col-md-8">
                                <?php if(isset($userData['icon'])): ?>
                                    <img src="<?php echo e(asset('storage/' . $userData['icon'])); ?>" 
                                         class="rounded-circle border shadow-sm" 
                                         style="width: 100px; height: 100px; object-fit: cover; " 
                                         alt="アイコン">
                                    <input type="hidden" name="icon" value="<?php echo e($userData['icon']); ?>">
                                <?php else: ?>
                                    <p class="text-muted">変更なし</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- ボタン -->
                    <div class="mt-3 d-flex justify-content-between">
                        <a href="<?php echo e(route('account.edit')); ?>" class="btn btn-secondary btn-lg px-4 py-2">
                            <i class="fas fa-arrow-left me-2"></i>戻る
                        </a>
                        <button type="submit" class="btn btn-primary btn-lg px-4 py-2">
                            <i class="fas fa-save me-2"></i>更新する
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/account_edit_conf.blade.php ENDPATH**/ ?>
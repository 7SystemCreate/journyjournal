

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="text-center mb-4">通報理由確認</h1>
    <form action="<?php echo e(route('report.comp')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="post_id" value="<?php echo e($post['id']); ?>">
        <div class="form-group">
            <textarea id="report_reason" name="report_reason" rows="5" class="form-control" readonly><?php echo e($report['report_reason']); ?></textarea>
        </div>
        <div class="form-group text-center mt-4">
            <a href="<?php echo e(route('post.report', ['post' => $post->id])); ?>" class="btn btn-secondary">戻る</a>
            <button type="submit" class="btn btn-primary">確定</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/report_conf.blade.php ENDPATH**/ ?>
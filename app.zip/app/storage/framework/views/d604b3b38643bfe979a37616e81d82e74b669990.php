

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php if($users->isNotEmpty()): ?> 
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-4">
                    <div class="card d-flex flex-row align-items-center p-3">
                        <!-- 左側: ユーザー情報 -->
                        <div class="col-8 d-flex flex-column">
                            <h5 class="mb-2"><?php echo e($user->name); ?></h5>
                            <p class="mb-2"><strong>メールアドレス:</strong> <?php echo e($user->email); ?></p>
                            <p class="mb-2"><strong>ロール:</strong> 
                                <?php echo e($user->role == 0 ? '一般ユーザ' : '旅館運営ユーザ'); ?>

                            </p>
                        </div>

                        <!-- 右下: 削除ボタン -->
                        <div class="col-4 d-flex justify-content-end align-items-end">
                            <a href="<?php echo e(route('delete.userdetail', ['user' => $user->id])); ?>" class="btn btn-danger">削除確認</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>ユーザーがいません。</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/user_list.blade.php ENDPATH**/ ?>
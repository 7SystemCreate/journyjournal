

<?php $__env->startSection('content'); ?>

<div class="container-fluid" style="margin-top: 20px;">
    <!-- 新規投稿ボタン -->
    <div class="row mb-4">
        <div class="col-12 text-left">
            <a href="<?php echo e(route('create.post')); ?>" class="btn btn-success">新規投稿</a>
        </div>
    </div>

    <div class="row">
        <?php if($posts->isNotEmpty()): ?> 
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-4">
                    <div class="card d-flex flex-row align-items-center p-3">
                        <div class="col-4">
                            <a href="<?php echo e(route('mypost.detail', ['post' => $post['id']])); ?>">
                                <img src="<?php echo e(asset('storage/' . ($post->image ?? 'images\postimages\defaultimage.png'))); ?>" class="img-fluid rounded" alt="投稿画像">
                            </a>
                        </div>

                        <div class="col-8 d-flex flex-column">
                            <!-- タイトル -->
                            <h5 class="mb-2">
                                <a href="<?php echo e(route('mypost.detail', ['post' => $post['id']])); ?>">
                                    <?php echo e($post->title); ?>

                                </a>
                            </h5>
                            <!-- 内容 (100字まで表示) -->
                            <p class="mb-2"><?php echo e(Str::limit($post->comment, 100)); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>投稿がありません。</p>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/inn_main.blade.php ENDPATH**/ ?>
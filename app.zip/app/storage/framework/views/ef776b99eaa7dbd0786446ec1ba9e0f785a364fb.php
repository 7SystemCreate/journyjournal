

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row align-items-center mb-3">
       <div class="col-md-6 d-flex align-items-center justify-content-start mt-4">
            <img src="<?php echo e(asset('storage/' . $user->icon)); ?>" 
                 class="rounded-circle" 
                 style="width: 80px; height: 80px; object-fit: cover;" 
                 alt="ユーザーアイコン">
            <h5 class="ml-3"><?php echo e($user->name); ?></h5>
        </div>

        <div class="col-md-6 text-right">
            <a href="<?php echo e(route('account.edit')); ?>" class="btn btn-outline-secondary">アカウント情報編集</a>
        </div>
    </div>

    <div class="row justify-content-center mt-5 px-7">
        <div class="col-md-6 d-flex justify-content-between">
            <a href="<?php echo e(route('general.mybooking')); ?>" class="btn btn-primary btn-lg py-3 px-4">予約一覧</a>
            <a href="<?php echo e(route('general.likelist')); ?>" class="btn btn-secondary btn-lg py-3 px-4">いいね一覧</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/general_mypage.blade.php ENDPATH**/ ?>
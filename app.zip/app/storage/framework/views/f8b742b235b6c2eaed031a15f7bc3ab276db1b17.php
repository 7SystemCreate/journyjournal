

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- 左側: 確認内容 -->
        <div class="col-md-6">
            <div class="card p-4 h-100">
                <h4 class="mb-3">予約内容の確認</h4>
                <table class="table">
                    <tr>
                        <th>氏名</th>
                        <td><?php echo e($booking['name']); ?></td>
                    </tr>
                    <tr>
                        <th>電話番号</th>
                        <td><?php echo e($booking['tel']); ?></td>
                    </tr>
                    <tr>
                        <th>チェックイン日</th>
                        <td><?php echo e($booking['checkin_date']); ?></td>
                    </tr>
                    <tr>
                        <th>チェックアウト日</th>
                        <td><?php echo e($booking['checkout_date']); ?></td>
                    </tr>
                    <tr>
                        <th>予約人数</th>
                        <td><?php echo e($booking['booking_people']); ?>人</td>
                    </tr>
                </table>

                <div class="d-flex justify-content-center">
                    <form action="<?php echo e(route('booking.comp')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="name" value="<?php echo e($booking['name']); ?>">
                        <input type="hidden" name="tel" value="<?php echo e($booking['tel']); ?>">
                        <input type="hidden" name="checkin_date" value="<?php echo e($booking['checkin_date']); ?>">
                        <input type="hidden" name="checkout_date" value="<?php echo e($booking['checkout_date']); ?>">
                        <input type="hidden" name="booking_people" value="<?php echo e($booking['booking_people']); ?>">
                        <input type="hidden" name="post_id" value="<?php echo e($post['id']); ?>">

                        <button type="submit" class="btn btn-success">予約確定</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- 右側: 予約のタイトル・料金詳細 -->
        <div class="col-md-6">
            <div class="card p-4 h-100 d-flex flex-column justify-content-between">
                <h4 class="mb-3"><?php echo e($post->title); ?></h4>
                <p class="text-muted"><?php echo e($post->comment); ?></p>
                <div class="bg-light p-3 rounded text-center">
                    <p class="fw-bold fs-4 mb-0">金額: <?php echo e(number_format($post->amount)); ?> 円</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/booking_conf.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h2 class="text-center font-weight-bold my-4">いいね一覧</h2>
    
    <?php if($posts->isNotEmpty()): ?> 
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-4">
                    <div class="card d-flex flex-row align-items-center p-3">
                        <div class="col-4">
                            <a href="<?php echo e(route('post.detail', ['post' => $post['id']])); ?>">
                                <img src="<?php echo e(asset('storage/' . ($post->image ?? 'images/postimages/defaultimage.png'))); ?>" 
                                     class="img-fluid rounded" alt="投稿画像">
                            </a>
                        </div>

                        <div class="col-8 d-flex flex-column">
                            <!-- タイトル -->
                            <h5 class="mb-2">
                                <a href="<?php echo e(route('post.detail', ['post' => $post['id']])); ?>">
                                    <?php echo e($post->title); ?>

                                </a>
                            </h5>

                            <!-- 内容 (100字まで表示) -->
                            <p class="mb-2"><?php echo e(Str::limit($post->comment, 100)); ?></p>

                            <!-- ユーザ名 & いいねボタン -->
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="text-muted mb-0">
                                    <?php if($post->user): ?>
                                        <?php echo e($post->user->name); ?>

                                    <?php else: ?>
                                        投稿者不明
                                    <?php endif; ?>
                                </p>
                                <!-- いいねボタン -->
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if($post->isLikedByUser(Auth::id())): ?>
                                        <!-- いいね済みボタン -->
                                        <button id="like-btn-<?php echo e($post->id); ?>" type="button" class="btn btn-outline-danger"
                                                onclick="unlikePost(<?php echo e($post->id); ?>)">
                                            いいねを取り消す <span id="like-count-<?php echo e($post->id); ?>"><?php echo e($post->likeCount()); ?></span>
                                        </button>
                                    <?php else: ?>
                                        <!-- まだいいねしていないボタン -->
                                        <button id="like-btn-<?php echo e($post->id); ?>" type="button" class="btn btn-outline-primary"
                                                onclick="likePost(<?php echo e($post->id); ?>)">
                                            いいね！ <span id="like-count-<?php echo e($post->id); ?>"><?php echo e($post->likeCount()); ?></span>
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p>まだ「いいね」をした投稿がありません。</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function likePost(postId) {
        $.ajax({
            url: '<?php echo e(route('post.like', ['post' => ':post_id'])); ?>'.replace(':post_id', postId),
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                if (response.success) {
                    // いいね数を更新
                    $('#like-count-' + postId).text(response.like_count);

                    // ボタンの切り替え
                    $('#like-btn-' + postId)
                        .removeClass('btn-outline-primary')
                        .addClass('btn-outline-danger')
                        .html(`いいねを取り消す <span id="like-count-${postId}">${response.like_count}</span>`)
                        .attr('onclick', 'unlikePost(' + postId + ')');
                } else {
                    alert('いいねの追加に失敗しました。');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('エラーが発生しました: ' + errorThrown);
                console.error(jqXHR.responseText);
            }
        });
    }

    function unlikePost(postId) {
        $.ajax({
            url: '<?php echo e(route('post.unlike', ['post' => ':post_id'])); ?>'.replace(':post_id', postId),
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                if (response.success) {
                    // いいね数を更新
                    $('#like-count-' + postId).text(response.like_count);

                    // ボタンの切り替え
                    $('#like-btn-' + postId)
                        .removeClass('btn-outline-danger')
                        .addClass('btn-outline-primary')
                        .html(`いいね！ <span id="like-count-${postId}">${response.like_count}</span>`)
                        .attr('onclick', 'likePost(' + postId + ')');
                } else {
                    alert('いいねの削除に失敗しました。');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('エラーが発生しました: ' + errorThrown);
                console.error(jqXHR.responseText);
            }
        });
    }
</script>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/like_list.blade.php ENDPATH**/ ?>
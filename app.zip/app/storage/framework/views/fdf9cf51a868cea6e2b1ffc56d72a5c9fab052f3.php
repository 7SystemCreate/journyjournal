<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'JournyJournal')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('stylesheet'); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand"
                    <?php if(Auth::check() && Auth::user()->role == 1): ?>
                        href="<?php echo e(route('inn.home')); ?>"
                    <?php elseif(Auth::check() && Auth::user()->role == 2): ?>
                        href="<?php echo e(route('admin.mypage')); ?>"
                    <?php else: ?>
                        href="<?php echo e(route('home')); ?>"
                    <?php endif; ?>
                    >JournyJournal
                </a>
            </div>
            <div class="my-navbar-control">
                <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->role == 2): ?> <!-- 管理者 -->
                        <a href="<?php echo e(route('admin.mypage')); ?>" class="my-navbar-item">
                            <img src="<?php echo e(asset('storage/' . Auth::user()->icon)); ?>" alt="アイコン" style="width: 30px; height: 30px; object-fit: cover; border-radius: 50%; margin-right: 8px;">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                    <?php elseif(Auth::user()->role == 1): ?> <!-- 旅館運営 -->
                        <a href="<?php echo e(route('inn.mypage')); ?>" class="my-navbar-item">
                            <img src="<?php echo e(asset('storage/' . Auth::user()->icon)); ?>" alt="アイコン" style="width: 30px; height: 30px; object-fit: cover; border-radius: 50%; margin-right: 8px;">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                    <?php elseif(Auth::user()->role == 0): ?> <!-- 一般 -->
                        <a href="<?php echo e(route('general.mypage')); ?>" class="my-navbar-item">
                            <img src="<?php echo e(asset('storage/' . Auth::user()->icon)); ?>" alt="アイコン" style="width: 30px; height: 30px; object-fit: cover; border-radius: 50%; margin-right: 8px;">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                    <?php endif; ?>
                    /
                    <a href="#" id="logout" class="my-navbar-item">ログアウト</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <script>
                        document.getElementById('logout').addEventListener('click', function(event) {
                            event.preventDefault();
                            document.getElementById('logout-form').submit();
                        });
                    </script>
                <?php else: ?>
                    <a class="my-navbar-item" href="<?php echo e(route('login')); ?>">ログイン</a>
                    /
                    <a class="my-navbar-item" href="<?php echo e(route('register')); ?>">会員登録</a>
                <?php endif; ?>
            </div>
        </nav>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/layout.blade.php ENDPATH**/ ?>